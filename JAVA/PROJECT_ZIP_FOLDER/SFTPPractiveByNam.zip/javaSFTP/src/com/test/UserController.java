package com.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

@Controller
@RequestMapping(value="/tts")
public class UserController {

	private String host = "222.239.250.173";
	private int port = 22;
	private String user = "Ym55";
	private String pass = "bmFteXVsNjQ=";
	private String serverPath = "/home/bny/nodejs/nys";
	//private String domainPath = "http://etcimg.kbsec.com/research/tts";
	
	private Session session = null;
	private Channel channel = null;
	private ChannelSftp channelSftp = null;
	
	@RequestMapping(value="/download", method = RequestMethod.GET)
	public @ResponseBody String ttsController(@RequestParam Map<String, String> req) throws Exception{
		
		System.out.println("ttsController");
		
		Decoder decoder = Base64.getDecoder();
		
		String documentid = req.get("documentid");
		String publicDate = req.get("publicdate");
		
		String accessUser = new String(decoder.decode(user), "UTF-8");
		String accessPass = new String(decoder.decode(pass), "UTF-8");
		
		init(host, accessUser, accessPass, port);
		
		String fileName = documentid + ".mp3";
		//String fileUrl = domainPath + dir + fileName;
		
		boolean checkFile = checkFileExist(serverPath, publicDate, fileName);
		
		disconnection();
		
		if(checkFile) {
			return "good";
		}
		
		return "bad";
		
	}
	
	public void init(String host, String userName, String password, int port) {
		
		System.out.println("init method");
		
		JSch jsch = new JSch();
		
		try {
			session = jsch.getSession(userName, host, port);
			session.setPassword(password);
			
			java.util.Properties config = new java.util.Properties();

            config.put("StrictHostKeyChecking", "no");

            session.setConfig(config);
			
            session.connect();

            channel = session.openChannel("sftp");

            channel.connect();
			
		} catch (JSchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		channelSftp = (ChannelSftp) channel;
		
	}
	
	public boolean checkFileExist(String dir, String publicDate, String fileName) {
		
		System.out.println("checkFileExist method");
		
		SftpATTRS attrs = null;
		String fileYear = publicDate.substring(0, 4);
		String fileMonth = publicDate.substring(4, 6);
		String fileDay = publicDate.substring(6, 8);
		String[] fileDate = {fileYear, fileMonth, fileDay};
		
		System.out.println(fileYear + " : " + fileMonth + " : " + fileDay);
		
		InputStream in = null;		
		boolean result = false;
		
		for(int i=0; i<fileDate.length; i++) {
			attrs = null;
			dir += "/" + fileDate[i];
			System.out.println(dir);
			try {
				attrs = channelSftp.stat(dir);
			} catch (SftpException e1) {
				// TODO Auto-generated catch block
				System.out.println("cannot find directory");				
				return result;
				
			}
		}
		
		System.out.println("channelSftp");
		
		try {
			
			channelSftp.cd(dir);
			
			in = channelSftp.get(fileName);
			
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			System.out.println("cannot find file");
			return result;
		}
		
		try {
			
			int i;
			
			while ((i = in.read()) != -1) {
				
                result = true;
                
            }
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			
		}finally {
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
		
		/*//�� ���丮 üũ
		try {
			attrs = channelSftp.stat(dir + "/" + fileYear);
			
		} catch (SftpException e1) {				
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if(attrs == null) return result;
		attrs = null;
		//�� ���丮 üũ
		
		try {
			attrs = channelSftp.stat(dir + "/" + fileYear + "/" + fileMonth);
		}catch(SftpException e2) {
			e2.printStackTrace();
		}
		
		if(attrs == null) return result;
		attrs = null;
		
		//�� ���丮 üũ
		try {
			System.out.println(dir);
			attrs = channelSftp.stat(dir + "/" + fileYear + "/" + fileMonth + "/" + fileDate);
		}catch(SftpException e3) {
			e3.printStackTrace();
		}*/
		
	}
	
	public void disconnection() {
		channelSftp.quit();
	}
	
	
	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public ModelAndView user() {
		User user = new User();
		user.setFavoriteFrameworks((new String[] { "Spring MVC", "Structs 2" }));
		ModelAndView mnv = new ModelAndView("user", "command", user);
		return mnv;
	}

	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("SpringWeb") User user, ModelMap model) {
		System.out.println(user.toString());
		model.addAttribute("username", user.getUsername());
		model.addAttribute("password", user.getPassword());
		model.addAttribute("address", user.getAddress());
		model.addAttribute("receivePaper", user.isReceivePaper());
		model.addAttribute("favoriteFrameworks", user.getFavoriteFrameworks());
		return "users";
	}

	@ModelAttribute("webFrameworkList")
	public List<String> getWebFrameworkList() {
		List<String> webFrameworkList = new ArrayList<String>();
		webFrameworkList.add("Spring MVC");
		webFrameworkList.add("Struts 1");
		webFrameworkList.add("Struts 2");
		webFrameworkList.add("Apache Wicket");
		return webFrameworkList;
	}
}
