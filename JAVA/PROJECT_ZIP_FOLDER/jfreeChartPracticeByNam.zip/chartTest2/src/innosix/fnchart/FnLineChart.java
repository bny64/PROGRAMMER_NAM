package innosix.fnchart;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateTickMarkPosition;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.axis.DateTickUnitType;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.data.time.TimePeriodValues;
import org.jfree.data.time.TimePeriodValuesCollection;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class FnLineChart {
	private JFreeChart chart;
	private Double maxPrice = 0.0;
	private Double minPrice = 0.0;
	private Double minVolume = 0.0;
	private Double maxVolume = 0.0;
	private Double basePrice = 0.0;
	
	public void writeChartAsPNG(OutputStream out, int width, int height) throws IOException {
		ChartUtils.writeChartAsPNG(out, chart, 800, 375);
	}
	
	private TimeSeriesCollection createPriceSeriesCollection(List<FnSeriesDataItem> items, int periodType) {
		
		TimeSeriesCollection seriesCollection = new TimeSeriesCollection();
		TimeSeries series = new TimeSeries("");
		
		Iterator<FnSeriesDataItem> it = items.iterator();
		FnSeriesDataItem item = null;
		
		double value = -1;
		while(it.hasNext()) {
			item = it.next();
			series.addOrUpdate(item);
			
			basePrice = item.getBaseValue();
			if(value == -1) {
				maxPrice = minPrice = value = (double) item.getValue();
			} else {
				value = (double) item.getValue();
				if(value > maxPrice) maxPrice = value;
				if(value < minPrice) minPrice = value;
			}
		}
		
		seriesCollection.addSeries(series);
		
		return seriesCollection;
	}
	
	
	private TimePeriodValuesCollection createVolumeSeriesCollection(List<FnSeriesDataItem> items, long periodTime) {
		TimePeriodValuesCollection seriesCollection = new TimePeriodValuesCollection();
		TimePeriodValues series = new TimePeriodValues("");
		Iterator<FnSeriesDataItem> it = items.iterator();
		FnSeriesDataItem item = null;
		Calendar cal = Calendar.getInstance();
		
		double value = -1;
		
		while(it.hasNext()) {
			item = it.next();
			
			cal.setTime(item.getPeriod().getStart());
			
			cal.add(Calendar.MILLISECOND, -((int) periodTime/5*4));
			Date startDate = cal.getTime();
			
			series.add(new SimpleTimePeriod(startDate, item.getPeriod().getStart()), item.getValue());
			
			if(value == -1) {
				maxVolume = value = (double) item.getValue();
			} else {
				value = (double) item.getValue();
				if(value > maxVolume) maxVolume = value;
			}
		}
		
		seriesCollection.addSeries(series);
		return seriesCollection;
	}
	
	
	@SuppressWarnings("deprecation")
	public void createChart(List<FnSeriesDataItem> priceItems, List<FnSeriesDataItem> volumeItems, 
			long periodTime, int numberType, int periodType, boolean volumeCheck) {
				
		int chartRange = periodType*20;
		
		int tickInterval = 0; //ƽ ����
		double resultMax = 0.0; //�ִ�
		double resultMin = 0.0; //�ּڰ�
		
		if(priceItems.size() > chartRange) {
			for(int i=priceItems.size()-1; i>chartRange; i--) {
				priceItems.remove(i);
				if(volumeCheck) volumeItems.remove(i);
			}
		}		
		
		TimeSeriesCollection collection = createPriceSeriesCollection(priceItems, periodType);
		TimePeriodValuesCollection collectionVolume = createVolumeSeriesCollection(volumeItems, periodTime);
						
		FnLineRenderer renderer = new FnLineRenderer();
		XYBarRenderer rendererVolume = new XYBarRenderer();
		
		DecimalFormat df = new DecimalFormat("#,###");
		
		if(numberType > -1) df.applyPattern("#,###.00");
		
		//================================================================

		TickVisibleDateAxis xAxis = new TickVisibleDateAxis();
		
		if(periodType==3) {
			tickInterval = 1;
		}else if(periodType==6) {
			tickInterval = 2;
		}else if(periodType==12) {
			tickInterval = 3;
		}
		
		xAxis.setAutoRange(true);
		xAxis.setTickLabelPaint(new Color(127,127,127));
		xAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
		xAxis.setDateFormatOverride(new SimpleDateFormat("MM.dd"));
		xAxis.setLowerMargin(0.01D);
		xAxis.setUpperMargin(0.01D);
		xAxis.setAutoRange(false);
		xAxis.setTimeline(SegmentedTimeline.newMondayThroughFridayTimeline());
		xAxis.setTickUnit(new DateTickUnit(DateTickUnitType.MONTH, tickInterval));
			
		Date maxdate = new Date();
		Date mindate = new Date();
		
		if(priceItems.size() > 1) {
			
			FnSeriesDataItem lastItem = priceItems.get(0);
			maxdate = lastItem.getPeriod().getStart();
			FnSeriesDataItem firstItem = priceItems.get(priceItems.size()-1);
			mindate = firstItem.getPeriod().getStart();
			xAxis.setRange(mindate, maxdate);
			
		}else {
			xAxis.setAutoRange(true);
		}
		
		/*else if(priceItems.size()==1) {
			
			FnSeriesDataItem lastItem = priceItems.get(0);			
			maxdate = lastItem.getPeriod().getStart();			
			cal.setTime(lastItem.getPeriod().getStart());
			cal.add(Calendar.MONTH, -periodType);
			mindate = cal.getTime();
						
		}else {
			
			maxdate = new Date();			
			cal.setTime(maxdate);
			cal.add(Calendar.MONTH, -periodType);
			mindate = cal.getTime();
			
		}*/
		
		
		
		//================================================================
		NumberAxis priceYAxis = new NumberAxis();
		NumberAxis volumeYAxis = new NumberAxis();
		
		priceYAxis.setTickLabelPaint(new Color(127,127,127));

		resultMax = maxPrice;
		resultMin = minPrice;
					
		//��� ��Ʈ tick label ���� unit���� ����
		//�Ҽ���
		priceYAxis.setTickUnit(new NumberTickUnit((resultMax-resultMin)/4.15));
		
		priceYAxis.setNumberFormatOverride(df);
		
		//��� ��Ʈ tick label ��Ʈ ����(null, �۲�, ������)
		priceYAxis.setTickLabelFont(new Font(null,Font.PLAIN,14));
		
		if(priceItems.size() > 1) {			
			priceYAxis.setRange(resultMin-(resultMax-resultMin)*0.1, resultMax+(resultMax-resultMin)*0.1);
			if(volumeCheck) volumeYAxis.setRange(minVolume, maxVolume * 1.1);			
		}else {
			priceYAxis.setAutoRange(true);
			volumeYAxis.setAutoRange(true);
		}		
		
		//�ϴ� ��Ʈ tick label ����
		volumeYAxis.setTickLabelsVisible(false);
		
		//�ϴ� ��Ʈ bar ���� ����
		rendererVolume.setBarPainter(new StandardXYBarPainter());
		rendererVolume.setSeriesPaint(0, new Color(83, 209, 129));
		
		//�ϴ� ��Ʈ bar �׸��� ����
		rendererVolume.setShadowVisible(false);
		//�ϴ� ��Ʈ ��Ʈ ���� 
		xAxis.setTickLabelFont(new Font(null, Font.PLAIN, 14));
		
		rendererVolume.setMargin(0.3);
		//================================================================
		XYPlot plot = new XYPlot(collection, xAxis, priceYAxis, renderer);
		plot.setBackgroundPaint(new Color(255,255,255));

		
		XYPlot plot2 = new XYPlot(collectionVolume, xAxis, volumeYAxis, rendererVolume);
		plot2.setBackgroundPaint(new Color(255,255,255));
		
		//================================================================
		CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(xAxis);
		combinedPlot.add(plot,4);
		if(volumeCheck) combinedPlot.add(plot2,1);
		
		chart = new JFreeChart("", JFreeChart.DEFAULT_TITLE_FONT, combinedPlot, false);
		chart.setBackgroundPaint(new Color(255,255,255));
	}
}
