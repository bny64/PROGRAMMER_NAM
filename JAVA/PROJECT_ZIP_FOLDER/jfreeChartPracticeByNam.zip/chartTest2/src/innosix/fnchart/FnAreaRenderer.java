package innosix.fnchart;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

public class FnAreaRenderer extends XYAreaRenderer {
	private static final long serialVersionUID = -8090425064429283097L;
	
	static class FnRendererState extends XYItemRendererState {
		public GeneralPath area;
		public Line2D line;
		public FnRendererState(PlotRenderingInfo info) {
			super(info);
			this.area = new GeneralPath();
			this.line = new Line2D.Double();
		}
	}
	
	@Override
	public XYItemRendererState initialise(Graphics2D g2, Rectangle2D dataArea, XYPlot plot, XYDataset data, PlotRenderingInfo info) {
		FnRendererState state = new FnRendererState(info);
		state.setProcessVisibleItemsOnly(false);
		return state;
	}
	
	@Override
	public void drawItem(Graphics2D g2, XYItemRendererState state, Rectangle2D dataArea, PlotRenderingInfo info, XYPlot plot,
			ValueAxis domainAxis, ValueAxis rangeAxis, XYDataset dataset, int series, int item, CrosshairState crosshairState, int pass) {
		if (!getItemVisible(series, item)) return;
		
		FnRendererState areaState = (FnRendererState) state;
		TimeSeriesCollection newdataset = (TimeSeriesCollection) dataset;
		FnSeriesDataItem newdataitem = (FnSeriesDataItem) newdataset.getSeries(series).getDataItem(item);
		
		double basevalue = newdataitem.getBaseValue();
		int itemCount = dataset.getItemCount(series);

		double x0 = dataset.getXValue(series, Math.max(item - 1, 0));
		double y0 = dataset.getYValue(series, Math.max(item - 1, 0));
		double x2 = dataset.getXValue(series, item);
		double y2 = dataset.getYValue(series, item);
		double x1 = 0.0;
		double y1 = basevalue;
		
		if (Double.isNaN(basevalue)) basevalue = 0.0;
		if (Double.isNaN(y0)) y1 = basevalue;
		if (Double.isNaN(y2)) y2 = basevalue;
		if (Double.isNaN(y0)) y0 = basevalue;
		
		double transX0 = domainAxis.valueToJava2D(x0, dataArea, plot.getDomainAxisEdge());
		double transY0 = rangeAxis.valueToJava2D(y0, dataArea, plot.getRangeAxisEdge());
		double transX1 = 0.0;
		double transY1 = rangeAxis.valueToJava2D(y1, dataArea, plot.getRangeAxisEdge());
		double transX2 = domainAxis.valueToJava2D(x2, dataArea, plot.getDomainAxisEdge());
		double transY2 = rangeAxis.valueToJava2D(y2, dataArea, plot.getRangeAxisEdge());
		
		Stroke stroke = getItemStroke(series, item);
		g2.setStroke(stroke);
		
		// ���ؼ�(y1)�� �������°�?
		boolean flag = false;
		if((y0 > basevalue && y2 > basevalue) || (y0 < basevalue && y2 < basevalue)){
			// ���ؼ�(y1)�� �������� ����
			flag = false;
			
			// x1�� x0,x2�� �߾Ӱ�
			x1 = x0 + ((x2-x0)/2); 
			
			transX1 = domainAxis.valueToJava2D(x1, dataArea, plot.getDomainAxisEdge());
		} else {
			// ���ؼ�(y1)�� ��������
			flag = true;
			
			// x1 ��ǥ ���
			double dist = Math.abs(y0-basevalue) + Math.abs(y2-basevalue);
			if(y0 > basevalue) {
				double rate = 1-((dist - Math.abs(y0-basevalue)) / dist);
				x1 = x0 + ((x2-x0)*rate);
			} else {
				double rate = (dist - Math.abs(y2-basevalue)) / dist;
				x1 = x0 + ((x2-x0)*rate);
			}
			
			transX1 = domainAxis.valueToJava2D(x1, dataArea, plot.getDomainAxisEdge());
		}
		
		Paint[] lineColor = {new Color(255,42,56), new Color(36,134,255)}; // [��»���,�϶�����]
		Paint[] fillColor = {new Color(255,42,56,25), new Color(36,134,255,25)}; // [��»���,�϶�����]
		
		// LINE
		if (item > 0) {
			if(!flag){
				// y2�� ���ذ����� ���� ���
				if(y2 > y1){
					g2.setPaint(lineColor[0]);
				} else {
					g2.setPaint(lineColor[1]); 
				}
				areaState.line.setLine(transX0, transY0, transX2, transY2);
				g2.draw(areaState.line);
			} else {
				// ���ؼ��� ����ġ�� ���󺯰��� �ʿ��ϱ� ������ �ι� �׸���.
				if(y0 > y1){
					g2.setPaint(lineColor[0]);
				} else {
					g2.setPaint(lineColor[1]); 
				}
				areaState.line.setLine(transX0, transY0, transX1, transY1);
				g2.draw(areaState.line);
				
				if(y2 > y1){
					g2.setPaint(lineColor[0]);
				} else {
					g2.setPaint(lineColor[1]); 
				}
				areaState.line.setLine(transX1, transY1, transX2, transY2);
				g2.draw(areaState.line);
			}
		}
		
		// AREA
		if(!flag){
			// y2�� ���ذ����� ���� ���
			if(y2 > y1){
				g2.setPaint(fillColor[0]);
			} else {
				g2.setPaint(fillColor[1]); 
			}
			
			areaState.area = new GeneralPath();
			moveTo(areaState.area, transX0, transY0);
			lineTo(areaState.area, transX0, transY1);
			lineTo(areaState.area, transX2, transY1);
			lineTo(areaState.area, transX2, transY2);
			areaState.area.closePath();
			
			g2.fill(areaState.area);
		} else {
			// ���ؼ��� ����ġ�� ���󺯰��� �ʿ��ϱ� ������ �ι� �׸���.
			if(y0 > y1){
				g2.setPaint(fillColor[0]);
			} else {
				g2.setPaint(fillColor[1]); 
			}
			areaState.area = new GeneralPath();
			moveTo(areaState.area, transX0, transY0);
			lineTo(areaState.area, transX0, transY1);
			lineTo(areaState.area, transX1, transY1);
			areaState.area.closePath();
			g2.fill(areaState.area);
			
			if(y2 > y1){
				g2.setPaint(fillColor[0]);
			} else {
				g2.setPaint(fillColor[1]); 
			}
			areaState.area = new GeneralPath();
			moveTo(areaState.area, transX1, transY1);
			lineTo(areaState.area, transX2, transY2);
			lineTo(areaState.area, transX2, transY1);
			areaState.area.closePath();
			g2.fill(areaState.area);
		}
	}
}
