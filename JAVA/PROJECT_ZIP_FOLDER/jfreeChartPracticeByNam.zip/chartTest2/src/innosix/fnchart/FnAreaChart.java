package innosix.fnchart;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLabelLocation;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickMarkPosition;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.axis.DateTickUnitType;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.data.time.TimePeriodValues;
import org.jfree.data.time.TimePeriodValuesCollection;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class FnAreaChart {
	private JFreeChart chart;
	private Double maxPrice = 0.0;
	private Double minPrice = 0.0;
	private Double minVolume = 0.0;
	private Double maxVolume = 0.0;
	private Double basePrice = 0.0;

	public void writeChartAsPNG(OutputStream out, int width, int height) throws IOException {
		ChartUtils.writeChartAsPNG(out, chart, 800, 375);
	}

	private TimeSeriesCollection createPriceSeriesCollection(List<FnSeriesDataItem> items) {
		TimeSeriesCollection seriesCollection = new TimeSeriesCollection();
		TimeSeries series = new TimeSeries("");

		Iterator<FnSeriesDataItem> it = items.iterator();
		FnSeriesDataItem item = null;

		double value = -1;
		while (it.hasNext()) {
			item = it.next();
			series.addOrUpdate(item);

			basePrice = item.getBaseValue();

			if (value == -1) {
				maxPrice = minPrice = value = (double) item.getValue();
			} else {
				value = (double) item.getValue();
				if (value > maxPrice)
					maxPrice = value;
				if (value < minPrice)
					minPrice = value;
			}

		}

		seriesCollection.addSeries(series);

		return seriesCollection;
	}

	//
	private TimeSeriesCollection createBasePriceSeriesCollection(List<FnSeriesDataItem> items) {
		TimeSeriesCollection seriesCollection = new TimeSeriesCollection();
		TimeSeries series = new TimeSeries("");

		Iterator<FnSeriesDataItem> it = items.iterator();
		FnSeriesDataItem item = null;

		while (it.hasNext()) {
			item = it.next();
			series.addOrUpdate(item);
		}

		seriesCollection.addSeries(series);
		return seriesCollection;
	}

	// volume chart �Ⱓ ����
	private TimePeriodValuesCollection createVolumeSeriesCollection(List<FnSeriesDataItem> items, long periodTime) {
		TimePeriodValuesCollection seriesCollection = new TimePeriodValuesCollection();
		TimePeriodValues series = new TimePeriodValues("");
		Iterator<FnSeriesDataItem> it = items.iterator();
		FnSeriesDataItem item = null;
		double value = -1;

		while (it.hasNext()) {
			item = it.next();

			Calendar cal = Calendar.getInstance();
			cal.setTime(item.getPeriod().getStart());

			cal.add(Calendar.MILLISECOND, -((int) periodTime / 5 * 4));
			Date startDate = cal.getTime();

			series.add(new SimpleTimePeriod(startDate, item.getPeriod().getStart()), item.getValue());
			if (value == -1) {
				maxVolume = value = (double) item.getValue();
			} else {
				value = (double) item.getValue();
				if (value > maxVolume)
					maxVolume = value;
			}
		}
		seriesCollection.addSeries(series);
		return seriesCollection;
	}

	@SuppressWarnings("deprecation")
	public void createChart(List<FnSeriesDataItem> priceItems, List<FnSeriesDataItem> volumeItems,
			List<FnSeriesDataItem> baseItems, long periodTime, int numberType) {
		TimeSeriesCollection collection = createPriceSeriesCollection(priceItems);
		TimeSeriesCollection baseCollection = createBasePriceSeriesCollection(baseItems);
		TimePeriodValuesCollection collectionVolume = createVolumeSeriesCollection(volumeItems, periodTime);
		FnAreaRenderer renderer = new FnAreaRenderer();
		XYBarRenderer rendererVolume = new XYBarRenderer();
		XYDotRenderer rendererBase = new XYDotRenderer();
		double resultMax = 0.0;
		double resultMin = 0.0;
		DecimalFormat df = new DecimalFormat("#,###");

		if (numberType > -1)
			df.applyPattern("#,###.00");
		// ================================================================

		TickVisibleDateAxis xAxis = new TickVisibleDateAxis();
		xAxis.setAutoRange(true);
		xAxis.setTickLabelPaint(new Color(127, 127, 127));
		xAxis.setTickUnit(new DateTickUnit(DateTickUnitType.MINUTE, 60));
		xAxis.setLabelLocation(AxisLabelLocation.LOW_END);
		xAxis.setDateFormatOverride(new SimpleDateFormat("HH"));
		xAxis.setLowerMargin(0.01D);
		xAxis.setUpperMargin(0.01D);
		xAxis.setAutoRange(false);

		if (priceItems.size() > 1) {

			FnSeriesDataItem firstItem = priceItems.get(0);
			Date mindate = firstItem.getPeriod().getStart();
			mindate.setHours(9);
			mindate.setMinutes(00);

			Date maxdate = firstItem.getPeriod().getStart();
			maxdate.setHours(16);
			maxdate.setMinutes(00);
			xAxis.setRange(mindate, maxdate);

		} else {

			xAxis.setAutoRange(true);

		}

		// ================================================================
		NumberAxis priceYAxis = new NumberAxis();
		NumberAxis volumeYAxis = new NumberAxis();

		priceYAxis.setTickLabelPaint(new Color(127, 127, 127));

		resultMax = maxPrice;
		resultMin = minPrice;

		if (priceItems.size() > 1) {

			if (basePrice > 0) {
				if (basePrice > maxPrice) {
					resultMax = basePrice;
				} else if (basePrice < minPrice) {
					resultMin = basePrice;
				}
				priceYAxis.setRange(resultMin - (resultMax - resultMin) * 0.1,
						resultMax + (resultMax - resultMin) * 0.1);
			}

			volumeYAxis.setRange(minVolume, maxVolume * 1.1);

		} else {
			priceYAxis.setAutoRange(true);
			volumeYAxis.setAutoRange(true);
		}

		// ��� ��Ʈ tick label ���� unit���� ����
		// �Ҽ���
		priceYAxis.setTickUnit(new NumberTickUnit((resultMax - resultMin) / 4.15));
		priceYAxis.setNumberFormatOverride(df);
		// ����
		// priceYAxis.setTickUnit(new
		// NumberTickUnit(Math.round((resultMax-resultMin)/4.15)));

		// ��� ��Ʈ tick label ��Ʈ ����(null, �۲�, ������)
		priceYAxis.setTickLabelFont(new Font(null, Font.PLAIN, 14));

		// �ϴ� ��Ʈ tick label ����
		volumeYAxis.setTickLabelsVisible(false);

		// �ϴ� ��Ʈ bar ���� ����
		rendererVolume.setSeriesPaint(0, new Color(83, 209, 129));
		rendererVolume.setBarPainter(new StandardXYBarPainter());

		// �ϴ� ��Ʈ bar �׸��� ����
		rendererVolume.setShadowVisible(false);

		// �ϴ� ��Ʈ ��Ʈ ����
		xAxis.setTickLabelFont(new Font(null, Font.PLAIN, 14));

		rendererBase.setSeriesPaint(0, new Color(0, 0, 0));
		rendererBase.setDotHeight(1);
		rendererBase.setDotWidth(3);
		// ================================================================
		XYPlot plot = new XYPlot(collection, xAxis, priceYAxis, renderer);
		plot.setBackgroundPaint(new Color(255, 255, 255));

		plot.setDataset(1, baseCollection);
		plot.setRenderer(1, rendererBase);

		XYPlot plot2 = new XYPlot(collectionVolume, xAxis, volumeYAxis, rendererVolume);
		plot2.setBackgroundPaint(new Color(255, 255, 255));

		// ================================================================
		CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(xAxis);
		combinedPlot.add(plot, 4);
		combinedPlot.add(plot2, 1);
		chart = new JFreeChart("", JFreeChart.DEFAULT_TITLE_FONT, combinedPlot, false);
		chart.setBackgroundPaint(new Color(255, 255, 255));
	}
}
