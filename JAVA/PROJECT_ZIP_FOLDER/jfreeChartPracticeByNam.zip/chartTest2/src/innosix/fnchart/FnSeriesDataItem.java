package innosix.fnchart;
import java.util.Date;

import org.jfree.chart.util.ObjectUtils;
import org.jfree.data.time.FixedMillisecond;
import org.jfree.data.time.TimeSeriesDataItem;

public class FnSeriesDataItem extends TimeSeriesDataItem {
	private static final long serialVersionUID = -2235346966016401303L;
	
	private double baseValue;
	
	public FnSeriesDataItem(Date date, double value) {
		super(new FixedMillisecond(date), value);
	}
	
	public FnSeriesDataItem(Date date, double value, double baseValue) {
		super(new FixedMillisecond(date), value);
		this.baseValue = new Double(baseValue);
	}
	
	public double getBaseValue() {
		return this.baseValue;
	}
	
	public void setBaseValue(double baseValue) {
		this.baseValue = baseValue;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof TimeSeriesDataItem)) {
			return false;
		}
		FnSeriesDataItem that = (FnSeriesDataItem) obj;
		if (!ObjectUtils.equal(getPeriod(), that.getPeriod())) {
			return false;
		}
		if (!ObjectUtils.equal(getValue(), that.getValue())) {
			return false;
		}
		if (!ObjectUtils.equal(getBaseValue(), that.getBaseValue())) {
			return false;
		}
		return true;
	}

}
