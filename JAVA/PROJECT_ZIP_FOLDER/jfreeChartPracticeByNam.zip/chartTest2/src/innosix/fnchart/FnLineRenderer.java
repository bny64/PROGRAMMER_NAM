package innosix.fnchart;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

public class FnLineRenderer extends XYAreaRenderer {
	private static final long serialVersionUID = -8090425064429283097L;
	
	static class FnRendererState extends XYItemRendererState {
		public Line2D line;
		public FnRendererState(PlotRenderingInfo info) {
			super(info);
			this.line = new Line2D.Double();
		}
	}
	
	@Override
	public XYItemRendererState initialise(Graphics2D g2, Rectangle2D dataArea, XYPlot plot, XYDataset data, PlotRenderingInfo info) {
		FnRendererState state = new FnRendererState(info);
		state.setProcessVisibleItemsOnly(false);
		return state;
	}
	
	@Override
	public void drawItem(Graphics2D g2, XYItemRendererState state, Rectangle2D dataArea, PlotRenderingInfo info, XYPlot plot,
			ValueAxis domainAxis, ValueAxis rangeAxis, XYDataset dataset, int series, int item, CrosshairState crosshairState, int pass) {
		if (!getItemVisible(series, item)) return;
		
		FnRendererState areaState = (FnRendererState) state;
		
		//������ǥ
		double x0 = dataset.getXValue(series, Math.max(item - 1, 0));
		double y0 = dataset.getYValue(series, Math.max(item - 1, 0));
		//������ǥ
		double x2 = dataset.getXValue(series, item);
		double y2 = dataset.getYValue(series, item);
		//�߾���
		
		double transX0 = domainAxis.valueToJava2D(x0, dataArea, plot.getDomainAxisEdge());
		double transY0 = rangeAxis.valueToJava2D(y0, dataArea, plot.getRangeAxisEdge());
		double transX2 = domainAxis.valueToJava2D(x2, dataArea, plot.getDomainAxisEdge());
		double transY2 = rangeAxis.valueToJava2D(y2, dataArea, plot.getRangeAxisEdge());
		
		Stroke stroke = getItemStroke(series, item);
		g2.setStroke(stroke);
		
		Paint[] lineColor = {new Color(255,42,56), new Color(36,134,255)}; // [��»���,�϶�����]
		
		if(item > 0) {
			g2.setPaint(lineColor[0]);
			areaState.line.setLine(transX0, transY0, transX2, transY2);
			g2.draw(areaState.line);
		}
	}
}
